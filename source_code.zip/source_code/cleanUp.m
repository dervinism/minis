% Clean-up before running scripts

fclose all;
close all
clear
clc