function faf = fafTest
faf = false;